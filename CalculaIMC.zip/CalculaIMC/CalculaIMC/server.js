const express = require('express');
const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

const PORT = 5000;

function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function layout(conteudo, bodyClass = '') {
    return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CalculaIMC</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;900&family=DM+Serif+Display&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/style.css">
</head>
<body class="${bodyClass}">
    <div class="container">
        ${conteudo}
    </div>
</body>
</html>`;
}

function classificarIMC(imc) {
    if (imc < 18.5) return { rota: 'abaixoPeso', label: 'Abaixo do Peso', emoji: '⚖️', cor: 'azul', msg: 'Seu corpo precisa de mais nutrientes. Considere consultar um nutricionista para um plano alimentar adequado.' };
    if (imc < 25)   return { rota: 'pesoNormal', label: 'Peso Normal',    emoji: '✅', cor: 'verde', msg: 'Parabéns! Você está na faixa ideal de peso. Continue mantendo seus hábitos saudáveis!' };
    if (imc < 30)   return { rota: 'sobrePeso',  label: 'Sobrepeso',      emoji: '⚠️', cor: 'amarelo', msg: 'Pequenas mudanças na alimentação e na atividade física fazem grande diferença no longo prazo.' };
    return              { rota: 'obesidade',  label: 'Obesidade',      emoji: '🩺', cor: 'vermelho', msg: 'Recomendamos consultar um médico para orientação personalizada sobre saúde e qualidade de vida.' };
}

app.get('/', (req, res) => {
    res.send(layout(`
        <div class="logo">💪</div>
        <h1>Calcula<span class="accent">IMC</span></h1>
        <p class="subtitle">Descubra seu Índice de Massa Corporal</p>

        <form action="/calcular" method="POST" class="form-imc" id="formIMC">
            <div class="input-group">
                <label for="nome">Nome</label>
                <input id="nome" name="nome" type="text" placeholder="Seu nome" maxlength="60" required />
            </div>
            <div class="input-row">
                <div class="input-group">
                    <label for="peso">Peso</label>
                    <div class="input-wrap">
                        <input id="peso" name="peso" type="number" step="0.1" min="10" max="500" placeholder="Ex: 70.5" required />
                        <span class="unit">kg</span>
                    </div>
                </div>
                <div class="input-group">
                    <label for="altura">Altura</label>
                    <div class="input-wrap">
                        <input id="altura" name="altura" type="number" step="0.01" min="0.5" max="3" placeholder="Ex: 1.75" required />
                        <span class="unit">m</span>
                    </div>
                </div>
            </div>
            <div id="erro" class="erro-msg" style="display:none"></div>
            <button type="submit" class="btn-primary">
                <span>Calcular IMC</span>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
            </button>
        </form>

        <a href="/informacoes" class="link-info">📊 Ver tabela de classificação</a>

        <script>
        document.getElementById('formIMC').addEventListener('submit', function(e) {
            const peso = parseFloat(document.getElementById('peso').value);
            const altura = parseFloat(document.getElementById('altura').value);
            const erro = document.getElementById('erro');
            if (peso < 10 || peso > 500) {
                e.preventDefault();
                erro.textContent = 'Peso deve estar entre 10 kg e 500 kg.';
                erro.style.display = 'block';
                return;
            }
            if (altura < 0.5 || altura > 3) {
                e.preventDefault();
                erro.textContent = 'Altura deve estar entre 0,5 m e 3 m.';
                erro.style.display = 'block';
                return;
            }
            erro.style.display = 'none';
        });
        </script>
    `));
});

app.post('/calcular', (req, res) => {
    let { nome, peso, altura } = req.body;
    peso = parseFloat(peso);
    altura = parseFloat(altura);

    if (!nome || isNaN(peso) || isNaN(altura) || peso < 10 || peso > 500 || altura < 0.5 || altura > 3) {
        return res.redirect('/');
    }

    const imc = (peso / (altura * altura)).toFixed(2);
    const { rota } = classificarIMC(parseFloat(imc));

    const params = new URLSearchParams({
        nome: nome.substring(0, 60),
        peso: peso.toFixed(1),
        altura: altura.toFixed(2),
        imc
    });

    res.redirect(`/${rota}?${params.toString()}`);
});

function paginaResultado(query) {
    const { nome, peso, altura, imc } = query;
    const imcNum = parseFloat(imc);

    if (!nome || isNaN(imcNum)) {
        return layout('<p>Dados inválidos. <a href="/">Voltar</a></p>');
    }

    const { label, emoji, cor, msg } = classificarIMC(imcNum);
    const alturaNum = parseFloat(altura);
    const pesoMinIdeal = (18.5 * alturaNum * alturaNum).toFixed(1);
    const pesoMaxIdeal = (24.9 * alturaNum * alturaNum).toFixed(1);
    const barraPercent = Math.min(Math.max(((imcNum - 10) / 35) * 100, 2), 98).toFixed(1);

    return layout(`
        <a href="/" class="btn-voltar"> Voltar</a>

        <div class="resultado-emoji">${emoji}</div>
        <h1 class="resultado-titulo">${escapeHtml(label)}</h1>
        <p class="resultado-nome">Olá, <strong>${escapeHtml(nome)}</strong>!</p>

        <div class="imc-destaque">
            <div class="imc-valor">${escapeHtml(imc)}</div>
            <p class="imc-label">Seu IMC</p>
        </div>

        <div class="barra-imc">
            <div class="barra-track">
                <div class="barra-azul"></div>
                <div class="barra-verde"></div>
                <div class="barra-amarelo"></div>
                <div class="barra-vermelho"></div>
                <div class="barra-marker" style="left: ${barraPercent}%">
                    <div class="marker-dot"></div>
                </div>
            </div>
            <div class="barra-labels">
                <span>Abaixo</span><span>Normal</span><span>Sobre</span><span>Obeso</span>
            </div>
        </div>

        <div class="dados-grid">
            <div class="dado">
                <span class="dado-label">Peso</span>
                <span class="dado-valor">${escapeHtml(peso)} kg</span>
            </div>
            <div class="dado">
                <span class="dado-label">Altura</span>
                <span class="dado-valor">${escapeHtml(altura)} m</span>
            </div>
            <div class="dado">
                <span class="dado-label">Faixa ideal</span>
                <span class="dado-valor">${pesoMinIdeal}–${pesoMaxIdeal} kg</span>
            </div>
        </div>

        <div class="msg-resultado cor-${cor}">${escapeHtml(msg)}</div>

        <a href="/informacoes" class="link-info">Ver tabela completa de IMC →</a>
    `, `pagina-resultado cor-${cor}`);
}

app.get('/abaixoPeso', (req, res) => res.send(paginaResultado(req.query)));
app.get('/pesoNormal', (req, res) => res.send(paginaResultado(req.query)));
app.get('/sobrePeso',  (req, res) => res.send(paginaResultado(req.query)));
app.get('/obesidade',  (req, res) => res.send(paginaResultado(req.query)));

app.get('/informacoes', (req, res) => {
    res.send(layout(`
        <a href="/" class="btn-voltar">← Voltar</a>
        <div class="logo">📊</div>
        <h1>O que é o <span class="accent">IMC</span>?</h1>
        <p class="subtitle">Índice de Massa Corporal</p>

        <div class="info-formula">
            <p class="formula-text">IMC = peso ÷ altura²</p>
            <p class="formula-exemplo">Exemplo: 70 ÷ (1,75)² = <strong>22,9</strong></p>
        </div>

        <h2 class="tabela-titulo">Classificação da OMS</h2>
        <table class="tabela-imc">
            <thead>
                <tr><th>IMC</th><th>Classificação</th><th></th></tr>
            </thead>
            <tbody>
                <tr class="linha-azul"><td>&lt; 18,5</td><td>Abaixo do peso</td><td>⚖️</td></tr>
                <tr class="linha-verde"><td>18,5 – 24,9</td><td>Peso normal</td><td>✅</td></tr>
                <tr class="linha-amarelo"><td>25,0 – 29,9</td><td>Sobrepeso</td><td>⚠️</td></tr>
                <tr class="linha-vermelho"><td>≥ 30,0</td><td>Obesidade</td><td>🩺</td></tr>
            </tbody>
        </table>

        <p class="aviso">⚠️ O IMC é uma referência geral e não substitui avaliação médica profissional.</p>

        <a href="/" class="btn-primary" style="display:inline-flex; margin-top:1.5rem; text-decoration:none">
            <span>Calcular meu IMC</span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </a>
    `));
});

app.listen(PORT, () => {
    console.log('Servidor rodando em http://localhost:' + PORT);
});
